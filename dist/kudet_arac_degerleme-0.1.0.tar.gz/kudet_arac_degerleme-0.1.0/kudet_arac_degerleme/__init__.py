# kudet/__init__.py

from .main import predict_price

