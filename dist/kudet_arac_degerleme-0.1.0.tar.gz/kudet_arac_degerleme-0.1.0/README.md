# KUDET: İkinci El Araç Değerleme Sistemi
