# kudet/main.py

def predict_price(car):
    """
    Basit araç fiyat tahmini fonksiyonu.
    Şimdilik sabit değer döner. Geliştirilecektir.
    """
    # Geçici sabit örnek fiyat
    return 350000

